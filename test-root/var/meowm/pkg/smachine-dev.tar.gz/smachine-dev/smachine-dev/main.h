#ifndef MAIN_H
#define MAIN_H

#define PROGRAM_BUFF_SIZE 1024

#endif // MAIN_H
