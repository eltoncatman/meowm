#ifndef PROGRAM_H
#define PROGRAM_H

#define BUFF_SIZE 64

#define IsValidChar(chr)  (isalpha(chr) || chr == '+' || chr == '-' || chr == '*' || chr == '/')

void program(char *expr);

#endif // PROGRAM_H
