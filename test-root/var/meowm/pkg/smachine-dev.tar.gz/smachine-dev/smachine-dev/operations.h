#ifndef OPERATIONS_H
#define OPERATIONS_H

#include <stddef.h>

extern double   stack[];
extern double   sv;
extern ssize_t  sp;

int   isop(char *op);
void  execute(char *op);

#endif // OPERATIONS_H
