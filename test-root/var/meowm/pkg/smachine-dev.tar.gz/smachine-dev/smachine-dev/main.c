#include <string.h>
#include <stdio.h>

#include "main.h"
#include "program.h"

int main(int argc, char *argv[])
{
	char program_buff[PROGRAM_BUFF_SIZE];

	if (argc != 2) {
		printf("USAGE: %s \"the expression\"\n", argv[0]);
		return 1;
	}

	strncpy(program_buff, argv[1], PROGRAM_BUFF_SIZE - 1);
	program(program_buff);

	return 0;
}
