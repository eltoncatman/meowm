#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "stack.h"
#include "program.h"
#include "operations.h"

void program(char *expr)
{
	double    val;
	unsigned  power;
	int       sign, val_check, buff_check;
	char      buff[BUFF_SIZE];
	size_t    buff_ind;

	buff_check  = 0;
	val_check   = 0;
	buff_ind    = 0;

	for (size_t ind = 0; expr[ind]; ++ind) {
		for (; isspace(expr[ind]); ++ind)
			;

		/* Calculating val: start */
		sign = (expr[ind] == '-') ? -1 : 1;

		if ((expr[ind] == '-' || expr[ind] == '+') && isdigit(expr[ind + 1]))
			++ind;

		if (isdigit(expr[ind]))
			val_check = 1;

		for (val = 0; isdigit(expr[ind]); ++ind)
			val = val * 10 + (expr[ind] - '0');

		if (expr[ind] == '.' && isdigit(expr[ind + 1]))
			++ind;

		for (power = 1; isdigit(expr[ind]); ++ind) {
			val = val * 10 + (expr[ind] - '0');
			power *= 10;
		}

		val = sign * (val / power);
		/* Calculating val: end */

		if (val_check) {
			if (!push(val)) {
				fprintf(stderr, "ERROR: could not push\n");
				exit(1);
			} else {
				val_check = 0;
				continue;
			}
		}

		/* The operaion case start */

		if (IsValidChar(expr[ind]))
			buff_check = 1;

		for (; IsValidChar(expr[ind]); ++buff_ind, ++ind)
			buff[buff_ind] = expr[ind];

		buff[buff_ind] = 0;
		buff_ind = 0;

		if (buff_check) {
			execute(buff);
			buff_check = 0;
		}

		/* The operaion case end */
	}

	dump();
}
