#ifndef STACK_H
#define STACK_H

#define STACK_SIZE     100
#define NUMS_PER_LINE  5

int push(double val);
int pop(void);
int dump(void);

#endif // STACK_H
