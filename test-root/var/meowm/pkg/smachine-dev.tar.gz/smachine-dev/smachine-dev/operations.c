#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "operations.h"
#include "stack.h"

extern double   stack[];
extern double   sv;
extern ssize_t  sp;

static const char *ops[] = {
	"+",
	"-",
	"*",
	"/",
	"stack",
	NULL
};

int isop(char *op)
{
	for (size_t ind = 0; ops[ind] != NULL; ++ind)
		if (!strcmp(ops[ind], op))
			return 1;

	return 0;
}

void execute(char *op)
{
	double op1, op2;

	/* The + operaion */
	if (!strcmp(op, "+")) {
		if (!pop()) {
			fprintf(stderr, "ERROR: could not pop\n");
			exit(1);
		}

		op2 = sv;

		if (!pop()) {
			fprintf(stderr, "ERROR: could not pop\n");
			exit(1);
		}

		op1 = sv;

		if (!push(op1 + op2)) {
			fprintf(stderr, "ERROR: could not push\n");
			exit(1);
		}

		return;
	}

	/* The - operaion */
	if (!strcmp(op, "-")) {
		if (!pop()) {
			fprintf(stderr, "ERROR: could not pop\n");
			exit(1);
		}

		op2 = sv;

		if (!pop()) {
			fprintf(stderr, "ERROR: could not pop\n");
			exit(1);
		}

		op1 = sv;

		if (!push(op1 - op2)) {
			fprintf(stderr, "ERROR: could not push\n");
			exit(1);
		}

		return;
	}	

	/* The * operaion */
	if (!strcmp(op, "*")) {
		if (!pop()) {
			fprintf(stderr, "ERROR: could not pop\n");
			exit(1);
		}

		op2 = sv;

		if (!pop()) {
			fprintf(stderr, "ERROR: could not pop\n");
			exit(1);
		}

		op1 = sv;

		if (!push(op1 * op2)) {
			fprintf(stderr, "ERROR: could not push\n");
			exit(1);
		}

		return;
	}		

	/* The / operaion */
	if (!strcmp(op, "/")) {
		if (!pop()) {
			fprintf(stderr, "ERROR: could not pop\n");
			exit(1);
		}

		op2 = sv;

		if (!op2) {
			fprintf(stderr, "ERROR: can't divide by 0\n");
			exit(1);
		}

		if (!pop()) {
			fprintf(stderr, "ERROR: could not pop\n");
			exit(1);
		}

		op1 = sv;

		if (!push(op1 / op2)) {
			fprintf(stderr, "ERROR: could not push\n");
			exit(1);
		}

		return;
	}

	/* Printing the stack operation */
	if (!strcmp(op, "stack")) {
		for (size_t ind = 0; ind < STACK_SIZE; ++ind) {
			if (ind % NUMS_PER_LINE == 0)
				printf("\n");

			printf("%7g ", stack[ind]);
		}

		printf("\n\n");

		return;
	}
}
