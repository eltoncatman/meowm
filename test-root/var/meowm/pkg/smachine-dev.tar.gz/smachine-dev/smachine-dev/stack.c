#include <stdio.h>

#include "stack.h"

double   stack[STACK_SIZE];
double   sv;
ssize_t  sp = 0;

int push(double val)
{
	if (sp >= 0 && sp < STACK_SIZE) {
		stack[sp++] = val;
		return 1;
	}

	return 0;
}

int pop()
{
	if (sp >= 0) {
		switch (sp) {
		default:
			sv = stack[--sp];
			stack[sp] = 0;
			break;
		case 0:
			sv = stack[0];
			stack[0] = 0;
			break;
		}

		return 1;
	}

	return 0;
}

/* The dump function is supposed to be executed
 once only! At the very end of the program */

int dump(void)
{
	if (sp >= 0) {
		switch (sp) {
		default:
			printf("%g\n", stack[--sp]);
			if (sp < STACK_SIZE - 1)
				stack[sp + 1] = 0;
			break;
		case 0:
			printf("%g\n", stack[0]);
			stack[0] = 0;
		}

		return 1;
	}

	return 0;
}
